
Izrazi obojene delove mreže kao delove stotine, desetice, decimalnim brojem i kao procenat od cele mreze.                                         
@center@ @mycanvas()@

Koji deo mreže je obojen (u procentima)? @hspacept(3)@ @lib.check_number(total, 20)@%